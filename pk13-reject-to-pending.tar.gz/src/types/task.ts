/**
 * 任務相關型別定義
 *
 * 定義任務（Task）本體、任務表單資料、指派人員、查詢參數，以及任務類型、
 * 狀態、警示狀態、班次、任務內容與重複規則等型別。
 */
import type { LicenseType } from './alert';

/** 任務（單筆排班/服務工作） */
export interface Task {
  id: string;
  groupId: string;
  groupName: string;
  branchId: string;
  branchName: string;
  taskType: TaskType;
  date: string;
  startTime: string;
  endTime: string;
  isOvernight: boolean;
  timeMode?: TimeMode;
  timeRemark?: string;
  headcount: number;
  shift: ShiftType;
  route: string;
  contents: TaskContent[];
  otherContentNote?: string;
  assignees: TaskAssignee[];
  remarks?: string;
  isMakeup?: boolean;
  originalDate?: string;
  makeupReason?: string;
  requirePhotos?: boolean;
  photoCount?: number;
  reportTypes?: ReportType[];
  photos?: string[];
  reportNotes?: string;
  recurrenceId?: string;
  recurrenceRule?: RecurrenceRule;
  /** 建立循環任務時，後端一次產生的筆數 */
  recurrenceCount?: number;
  status: TaskStatus;
  isApproved?: boolean;
  isFromPending?: boolean;
  alertStatus: AlertStatus;
  overrideRemark?: string;
  /** 副總駁回原因；任務回待排區後顯示，重新排班後清除 */
  rejectReason?: string;
  /** 駁回時被移除的指派人員姓名 */
  rejectedAssignees?: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

/** 任務表單資料（建立/編輯任務時使用，指派人員以 ID 陣列表示） */
export interface TaskFormData {
  groupId: string;
  groupName?: string;
  branchId: string;
  branchName?: string;
  taskType: TaskType;
  date: string;
  startTime: string;
  endTime: string;
  timeMode?: TimeMode;
  timeRemark?: string;
  headcount: number;
  shift: ShiftType;
  route: string;
  contents: TaskContent[];
  otherContentNote?: string;
  assignees: string[];
  remarks?: string;
  isMakeup?: boolean;
  originalDate?: string;
  makeupReason?: string;
  requirePhotos?: boolean;
  photoCount?: number;
  reportTypes?: ReportType[];
  photos?: string[];
  reportNotes?: string;
  recurrence?: RecurrenceRule;
  /** 循環任務的修改／取消範圍：this = 僅此次；thisAndFuture = 此次及之後 */
  recurrenceModifyScope?: 'this' | 'thisAndFuture';
  status?: TaskStatus;
  isFromPending?: boolean;
  /** 從待排拖進日曆：後端保存原本的排班欄位 */
  snapshotPending?: boolean;
  /** 整筆移回待排：後端還原排班欄位 */
  restorePending?: boolean;
  overrideRemark?: string;
  alertStatus?: AlertStatus;
}

/** 任務指派人員（含姓名與持有證照，供顯示與警示規則檢查使用） */
export interface TaskAssignee {
  employeeId: string;
  employeeName: string;
  licenses: LicenseType[];
  area?: string;
  groupId?: string;
  groupColor?: string;
}

/** 任務列表查詢參數 */
export interface TaskListParams {
  page?: number;
  pageSize?: number;
  keyword?: string;
  groupId?: string;
  branchId?: string;
  taskType?: TaskType;
  status?: TaskStatus;
  startDate?: string;
  endDate?: string;
  area?: string;
}

/** 任務類型：合約／單次／ESR */
export type TaskType = 'CONTRACT' | 'ONETIME' | 'ESR';
/** 任務狀態：未排班／已排班／已更改／已確認／待核准／已取消 */
export type TaskStatus =
  'UNSCHEDULED' | 'SCHEDULED' | 'MODIFIED' | 'CONFIRMED' | 'PENDING_APPROVAL' | 'CANCELLED';
/** 警示狀態：無警示／有違規／已特許 */
export type AlertStatus = 'CLEAN' | 'VIOLATED' | 'OVERRIDDEN' | 'REJECTED';
/** 任務時間類型：固定時段／彈性（當日內完成，不指定時段） */
export type TimeMode = 'FIXED' | 'FLEXIBLE';
/** 回報方式：APP 填寫／EDM 電子郵件／紙本回報／拍照存證 */
export type ReportType = 'APP' | 'EDM' | 'PAPER' | 'PHOTO';
/** 班次類型（由後端動態提供，例如 '台北早班'、'台北晚班'） */
export type ShiftType = string; // Dynamic from backend (e.g., '台北早班', '台北晚班')
/** 任務內容項目（服務項目代碼，相容預設列舉與未來任意動態代碼擴充） */
export type TaskContent =
  | 'P'
  | 'R'
  | 'S'
  | 'TERMITE'
  | 'FIRE_ANT'
  | 'BED_BUG'
  | 'VEHICLE_MAINTENANCE'
  | 'TRAINING'
  | 'OTHER'
  | (string & {});

/** 重複規則（用於定期任務，如每日/每週/每月/自訂重複） */
export interface RecurrenceRule {
  frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'custom';
  interval: number;
  daysOfWeek?: number[];
  dayOfMonth?: number;
  endType: 'never' | 'date' | 'count';
  endDate?: string;
  endCount?: number;
}
